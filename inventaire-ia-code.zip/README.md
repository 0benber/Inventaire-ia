# Inventaire IA

Application web pour inventorier des objets avec photo et description.